package com.shayan.feature.product_image.service

import com.shayan.core.exception.FailedToAdd
import com.shayan.core.image_controller.ImageController
import com.shayan.core.image_controller.ImageType
import com.shayan.core.response.IdIpDTO
import com.shayan.feature.employee_audit_log.constants.EmployeeAuditLogConst
import com.shayan.feature.employee_audit_log.service.EmployeeAuditLogService
import com.shayan.feature.product_image.constants.ProductImageConst
import com.shayan.feature.product_image.dto.ProductImageResponse
import com.shayan.feature.product_image.mapper.toProductImageResponse
import com.shayan.feature.product_image.model.ProductImage
import com.shayan.feature.product_image.repository.ProductImageRepository
import core.database.dbQuery
import core.util.IdGenerator
import io.ktor.http.cio.Request
import io.ktor.server.plugins.*

class ProductImageService(
    private val repository: ProductImageRepository,
    private val employeeAuditLogService: EmployeeAuditLogService,
    private val imageController: ImageController
) {

    suspend fun add(
        employeeId: String,
        roleId: String,
        productId: String,
        ip: String,
        fileBytes: ByteArray,
        originalFileName: String?,
        previewImage: Boolean,
        baseUrl: String
    ): ProductImageResponse {

        runCatching {
            employeeAuditLogService.addAuditLog(
                employeeId = employeeId,
                roleId = roleId,
                action = ProductImageConst.ADD_ACTION,
                ip = ip
            )
        }

        return dbQuery {

            val existingPreview = repository.findPreview(productId)

            val shouldBePreview =
                previewImage || existingPreview == null

            if (shouldBePreview) {
                repository.clearPreview(productId)
            }

            val fileName = imageController.addImage(
                fileBytes = fileBytes,
                title = originalFileName,
                imageType = ImageType.ProductImage
            )

            val request = ProductImage(
                id = IdGenerator.generate(),
                productId = productId,
                previewImage = shouldBePreview,
                title = fileName
            )

            repository.add(request)
                ?.toProductImageResponse(
                    "$baseUrl${ProductImageConst.IMAGE_ROUTE}/${fileName}"
                )
                ?: throw FailedToAdd()
        }
    }

    suspend fun readPreview(
        productId: String,
        baseUrl: String
    ): ProductImageResponse =
        dbQuery {

            val result =  repository.findPreview(productId)
            result?.toProductImageResponse(
                "$baseUrl${ProductImageConst.IMAGE_ROUTE}/${result.title}"
            )
                ?: throw NotFoundException()
        }

    suspend fun readAll(
        productId: String,
        baseUrl: String
    ): List<ProductImageResponse> =
        dbQuery {

            repository.findAll(productId)
                .map {
                    it.toProductImageResponse(
                        "$baseUrl${ProductImageConst.IMAGE_ROUTE}/${it.title}"
                    )
                }
        }

    suspend fun updateImage(
        employeeId: String,
        roleId: String,
        imageId: String,
        ip: String,
        fileBytes: ByteArray,
        baseUrl: String
    ): ProductImageResponse {

        runCatching {
            employeeAuditLogService.addAuditLog(
                employeeId = employeeId,
                roleId = roleId,
                action = ProductImageConst.UPDATE_IMAGE_ACTION,
                ip = ip
            )
        }

        return dbQuery {

            val existing =
                repository.findById(imageId)
                    ?: throw NotFoundException()

            imageController.updateImage(
                image = fileBytes,
                title = existing.title,
                imageType = ImageType.ProductImage
            )

            repository.update(existing)
                ?.toProductImageResponse(
                    "$baseUrl${ProductImageConst.IMAGE_ROUTE}/${existing.title}"
                )
                ?: throw NotFoundException()
        }
    }

    suspend fun updatePreview(
        employeeId: String,
        roleId: String,
        request: IdIpDTO,
        baseUrl: String
    ): ProductImageResponse {

        runCatching {
            employeeAuditLogService.addAuditLog(
                employeeId = employeeId,
                roleId = roleId,
                action = ProductImageConst.UPDATE_PREVIEW_ACTION,
                ip = request.ip
            )
        }

        return dbQuery {

            val image =
                repository.findById(request.id)
                    ?: throw NotFoundException()

            repository.clearPreview(image.productId)


            val result =  repository.setPreview(request.id)
            result?.toProductImageResponse(
                "$baseUrl${ProductImageConst.IMAGE_ROUTE}/${result.title}"
            )
                ?: throw NotFoundException()
        }
    }

    suspend fun deleteSingle(
        employeeId: String,
        roleId: String,
        request: IdIpDTO
    ) {

        runCatching {
            employeeAuditLogService.addAuditLog(
                employeeId = employeeId,
                roleId = roleId,
                action = ProductImageConst.DELETE_SINGLE_ACTION,
                ip = request.ip
            )
        }

        dbQuery {

            val existing =
                repository.findById(request.id)
                    ?: throw NotFoundException()

            val deleted = imageController.deleteImage(
                title = existing.title,
                imageType = ImageType.ProductImage
            )

            if (!deleted) {
                throw NotFoundException()
            }

            repository.delete(request.id)

            if (existing.previewImage) {

                val remaining =
                    repository.findAll(existing.productId)

                if (remaining.isNotEmpty()) {
                    repository.setPreview(
                        remaining.first().id
                    )
                }
            }
        }
    }

    suspend fun deleteAll(
        employeeId: String,
        roleId: String,
        request: IdIpDTO
    ) {

        runCatching {
            employeeAuditLogService.addAuditLog(
                employeeId = employeeId,
                roleId = roleId,
                action = ProductImageConst.DELETE_ALL_ACTION,
                ip = request.ip
            )
        }

        dbQuery {

            repository.findAll(request.id)
                .forEach {

                    imageController.deleteImage(
                        title = it.title,
                        imageType = ImageType.ProductImage
                    )
                }

            repository.deleteAll(request.id)
        }
    }

    suspend fun readPreviewImage(
        productId: String,
        baseUrl: String
    ): ProductImageResponse? =
        dbQuery {

            val result = repository.findPreview(productId)
                ?: return@dbQuery null

            result.toProductImageResponse(
                "$baseUrl${ProductImageConst.IMAGE_ROUTE}/${result.title}"
            )
        }
}