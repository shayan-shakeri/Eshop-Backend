package com.shayan.feature.employee_audit_log.table

import com.shayan.feature.employee.table.EmployeeTable
import com.shayan.feature.employee_audit_log.constants.EmployeeAuditLogConst
import com.shayan.feature.role.table.RoleTable
import core.consts.ANC
import org.jetbrains.exposed.sql.ReferenceOption
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.javatime.timestamp

object EmployeeAuditLogTable: Table(EmployeeAuditLogConst.TABLE_NAME) {
    val id = varchar(EmployeeAuditLogConst.ID, ANC.ID_LENGTH)
    val employee_id = varchar(EmployeeAuditLogConst.EMPLOYEE_ID, ANC.ID_LENGTH).references(
        EmployeeTable.id,
        onUpdate = ReferenceOption.RESTRICT,
        onDelete = ReferenceOption.SET_NULL
    ).nullable()
    val role_id = varchar(EmployeeAuditLogConst.CODE, ANC.ID_LENGTH)
    val action = text(EmployeeAuditLogConst.ACTION)
    val ip = varchar(EmployeeAuditLogConst.IP, EmployeeAuditLogConst.IP_LENGTH)
    val created_at = timestamp(EmployeeAuditLogConst.CREATED_AT)

    override val primaryKey = PrimaryKey(id)
}